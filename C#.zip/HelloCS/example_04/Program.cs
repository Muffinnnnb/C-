﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //alt 빙향키 : 이동
            if(false)//실행안함
            {
                //#region ~ #endregion 영역만들기
                #region 1번 ~ 7번문제

            //1번문제
            int sum = 0;
            for (int i = 1; i <= 100; i++)
            {
                sum += i;
            }
            Console.WriteLine(sum);

            //2번 문제
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            sum = 0;
            for (int i = a; i <= b; i++)
            {
                if (i % 3 == 0)
                {
                    sum += i;
                }
            }
            Console.WriteLine($"{a}~{b}중 3의 배수의 합 : {sum}");



            //3번 문제
            for (char i = 'A'; i <= 'z'; i++)
            {
                if ((i >= 'A' && i <= 'Z') || (i >= 'a' && i <= 'z'))
                {
                    Console.Write(i);
                }
            }

            for (char i = 'A'; i <= 'z'; i++)
            {
                if (i > 'Z' && i < 'a')
                {
                    continue;//사이의 특수문자를 만났을때 출력하지 않고 다음조건으로 넘어감
                }
                Console.Write(i);
            }

            //4번 문제
            while (true)
            {
                Console.ReadLine();
                if (Console.ReadLine() == "exit")
                {
                    break;
                }
            }

            Console.WriteLine();
            Console.WriteLine("입력");
            while (Console.ReadLine() != "exit")
            {
                Console.WriteLine("입력");
            }

            do
            {
                Console.WriteLine("입력");
            } while (Console.ReadLine() != "exit");


            //5번 문제
            int[] num = new int[5];
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("정수입력");
                num[i] = int.Parse(Console.ReadLine());
            }
            int max = num[0];
            int min = num[0];
            for (int i = 0; i < 5; i++)
            {
                if (max < num[i])
                    max = num[i];
                if (min > num[i])
                    min = num[i];
            }
            Console.WriteLine("max : " + max + "min : " + min);

            //6번문제
            Array.Sort(num);//숫자 정렬
            //배열의 길이만큼 반복
            foreach (var item in num)
                Console.WriteLine(item);

            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i]);
            }

            //7번문제
            //버블정렬
            Array.Reverse(num);//현재 배열의 순서를 반대로
            for (int i = 0; i < num.Length; i++)
            {
                for (int j = 0; j < num.Length - 1; j++)
                {
                    if (num[j] > num[j + 1])
                    {
                        int temp = num[j];
                        num[j] = num[j + 1];
                        num[j + 1] = temp;
                    }
                }
            }
            foreach (var item in num)
            {
                Console.WriteLine(item);
            }

            //선택정렬
            Array.Reverse(num);
            int minth = 0;//가장 작은값의 인덱스
            for (int i = 0; i < num.Length - 1; i++)
            {
                minth = i;
                for (int j = i + 1; j < num.Length; j++)
                {
                    if (num[j] < num[minth])
                    {
                        minth = j;//j보다 클때
                    }
                    int temp = num[minth];
                    num[minth] = num[i];
                    num[i] = temp;
                }
                foreach (var item in num)
                {
                    Console.WriteLine(item);
                }
            }

            #endregion
            }

            if (false)
            {
                #region 개미수열

            //8번문제
            string start = "1";
            for (int i = 0; i < 20; i++)
            {
                Console.WriteLine($"{i+1}번째 : {start}");
                string end = "";//임시 저장소(누적값저장)
                char number = start[0];//내가 읽을값
                int count = 0;//내가 읽은 값의 개수
                for (int j = 0; j < start.Length; j++)//읽고 말하는 부분
                {
                    if(start[j] != number)//읽은 값이 바뀔때
                    {
                        end = end + number + count;
                        number = start[j];
                        count = 1;//새로운 값을 발견하여 1로 시작
                    }
                    else//읽은 값이 그대로일경우
                        count++;
                }
                //i+1번째 최종결과
                end = end + number + count;//가장 마지막에 읽은 값
                start = end;//start에 대입후, 다음 for문에서 말함
            }
            #endregion
            }
            if (false)
            {
                #region GoTo

            while (true)
            {
                string input=Console.ReadLine();
                if (input == "goto")
                {
                    goto myant;//내가 지정해둔 영역으로 이동
                }
                else if (input == "exit")
                { 
                    break;
                }

                Console.WriteLine("goto문으로 이동시 생략되는곳");
                myant:
                Console.WriteLine("내가 원하는 지점으로 이동");//위의 출력문을 생략
            }
            #endregion
            }

            //원본을 바꾸는게 아님
            string ex = "  HongGillDong@선생님!C#담당  ";
            Console.WriteLine(ex.ToUpper());//원본을 전부 대문자로 반환
            Console.WriteLine(ex.ToLower());//원본을 전부 소문자로 반환
            Console.WriteLine(ex);//원본은 안바뀐다 ("abc"!="ABC")
            Console.WriteLine(ex.Trim());//공백제거
            Console.WriteLine(ex);//원본

            //기준 문자를 가지고 문자열을 이용해 문자열 배열 만들기
            string[] result_1 = ex.Split('@');//@를 기준으로 문자열을 자름(양방향 송.수신시 사용)
            Console.WriteLine(result_1[0]);
            Console.WriteLine(result_1[1]);
            string[] result_2 = ex.Split(new char[] {'@','!'});
            Console.WriteLine(result_2[0]);
            Console.WriteLine(result_2[1]);
            Console.WriteLine(result_2[2]);

            string joinResult = string.Join(",",result_2);
            Console.WriteLine(joinResult);
        }
    }
}
