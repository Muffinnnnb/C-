﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            if ((DateTime.Now.Year) % 12 == 4)
                Console.WriteLine("자");
            else if ((DateTime.Now.Year) % 12 == 5)
                Console.WriteLine("축");
            else if ((DateTime.Now.Year) % 12 == 6)
                Console.WriteLine("인");
            else if ((DateTime.Now.Year) % 12 == 7)
                Console.WriteLine("묘");
            else if ((DateTime.Now.Year) % 12 == 8)
                Console.WriteLine("진");
            else if ((DateTime.Now.Year) % 12 == 9)
                Console.WriteLine("사");
            else if ((DateTime.Now.Year) % 12 == 10)
                Console.WriteLine("오");
            else if ((DateTime.Now.Year) % 12 == 11)
                Console.WriteLine("미");
            else if ((DateTime.Now.Year) % 12 == 0)
                Console.WriteLine("신");
            else if ((DateTime.Now.Year) % 12 == 1)
                Console.WriteLine("유");
            else if ((DateTime.Now.Year) % 12 == 2)
                Console.WriteLine("술");
            else if ((DateTime.Now.Year) % 12 == 3)
                Console.WriteLine("해");
            else
                Console.WriteLine("잘못된 값");

            if (DateTime.Now.Month >= 1 && DateTime.Now.Month <= 2)
                Console.WriteLine("겨울");
            else if(DateTime.Now.Month >= 3 &&DateTime.Now.Month <= 5)
                Console.WriteLine("봄");
            else if(DateTime.Now.Month >= 6 &&DateTime.Now.Month <= 8)
                Console.WriteLine("여름");
            else if(DateTime.Now.Month >= 9 && DateTime.Now.Month <= 11)
                Console.WriteLine("가을");
            else if(DateTime.Now.Month == 12)
                Console.WriteLine("겨울");
            else
                Console.WriteLine("잘못된 값");





        }
    }
}
