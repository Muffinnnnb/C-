﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myCsharp_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //문제 1

            //올해가 무슨띠 인지?
            //12년 마다 계속 순환함
            //12로 나눈 나머지값을 이용
            int year=DateTime.Now.Year;
            switch (year%12)
            {
                case 0:
                    Console.WriteLine("원숭이");
                    break;
                case 1:
                    Console.WriteLine("닭");
                    break;
                case 2:
                    Console.WriteLine("개");
                    break;
                case 3:
                    Console.WriteLine("돼지");
                    break;
                case 4:
                    Console.WriteLine("쥐");
                    break;
                case 5:
                    Console.WriteLine("소");
                    break;
                case 6:
                    Console.WriteLine("호랑이");
                    break;
                case 7:
                    Console.WriteLine("토끼");
                    break;
                case 8:
                    Console.WriteLine("용");
                    break;
                case 9:
                    Console.WriteLine("뱀");
                    break;
                case 10:
                    Console.WriteLine("말");
                    break;
                case 11:
                    Console.WriteLine("양");
                    break;
                default:
                    Console.WriteLine("잘못된 값");
                    break ;
            }
            //2번문제

            int month=DateTime.Now.Month;
            if (month == 12 || month == 1 || month == 2)
                Console.WriteLine("겨울");
            else if (month == 3 || month == 4 || month == 5)
                Console.WriteLine("봄");
            else if (month == 6 || month == 7 || month == 8)
                Console.WriteLine("여름");
            else if (month == 9 || month == 10 || month == 11)
                Console.WriteLine("가을");
            else
                Console.WriteLine("잘못된 값");

            //3번문제
            //1989년 - 기사
            //2049년 - 환갑 (60년)
            string 십간십이지 = "";//간지
            switch (year%10)//갑을병정무기경신임계 ->10개 순환
            {
                case 0:
                    십간십이지 += "경";
                    break;
                case 1:
                    십간십이지 += "신";
                    break;
                case 2:
                    십간십이지 += "임";
                    break;
                case 3:
                    십간십이지 += "계";
                    break;
                case 4:
                    십간십이지 += "갑";
                    break;
                case 5:
                    십간십이지 += "을";
                    break;
                case 6:
                    십간십이지 += "병";
                    break;
                case 7:
                    십간십이지 += "정";
                    break;
                case 8:
                    십간십이지 += "무";
                    break;
                case 9:
                    십간십이지 += "기";
                    break;
                default:
                    Console.WriteLine("잘못된 값");
                    십간십이지 = "";
                    break;
            }

            switch (year % 12)
            {
                case 0:
                    십간십이지 += "신";
                    break;
                case 1:
                    십간십이지 += "유";
                    break;
                case 2:
                    십간십이지 += "술";
                    break;
                case 3:
                    십간십이지 += "해";
                    break;
                case 4:
                    십간십이지 += "자";
                    break;
                case 5:
                    십간십이지 += "축";
                    break;
                case 6:
                    십간십이지 += "인";
                    break;
                case 7:
                    십간십이지 += "묘";
                    break;
                case 8:
                    십간십이지 += "진";
                    break;
                case 9:
                    십간십이지 +="사";
                    break;
                case 10:
                    십간십이지 += "오";
                    break;
                case 11:
                    십간십이지 += "미";
                    break;
                default:
                    Console.WriteLine("잘못된 값");
                    break;
            }
            Console.WriteLine("올해는"+십간십이지+"년 입니다.");
            //한글변수 가능하지만 사용X
            
        }
    }
}
