﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace example_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1번
            Console.Write("Write");
            Console.WriteLine("WriteLine");
            Console.WriteLine("WriteLine");
            Console.WriteLine("WriteLine"); //ctrl + d 복붙
            Console.Write("Write");
            Console.Write("Write");
            Console.WriteLine();

            //2번
            Console.WriteLine("몇 INCH? : ");
            //Consol.ReadLine(); String 입력
            //int.Parse("123") -> int형
            int inch=int.Parse(Console.ReadLine());
            Console.WriteLine(inch*2.54);

            //3번
            Console.WriteLine("몇 KG? :");
            int kg=int.Parse(Console.ReadLine());
            Console.WriteLine($"{kg}kg={kg*2.20462262} Pound");

            //4번
            Console.WriteLine("반지름 입력 :");
            int r=int.Parse(Console.ReadLine());
            Console.WriteLine($"원의 둘레={r*2*3.14}, 넓이={r*r*3.14}");

            //5번
            Console.WriteLine("첫번째 숫자 입력 : ");
            int one = int.Parse(Console.ReadLine());
            Console.WriteLine("두번째 숫자 입력 : ");
            int two = int.Parse(Console.ReadLine());
            Console.WriteLine(one * (two % 10));//첫번째 숫자 곱하기 두번째 숫자의 1의 자리수
            Console.WriteLine(one * ((two / 10) % 10));//첫번째 숫자 곱하기 두번째 숫자의 10의 자리수
            Console.WriteLine(one * (two / 100));//첫번째 숫자 곱하기 두번째 숫자의 100의 자리수
            Console.WriteLine(one * two);//첫번째 숫자 곱하기 두번째 숫자
            
            //단체 주석 - ctrl + ku


        }
    }
}
