﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myCsharp_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            //escape 문자
            //쌍따옴표 안에서 쌍따옴표 출력
            Console.WriteLine("안녕\"홍길동\"학생");
            //쌍따옴표 안에서 \ 출력
            Console.WriteLine("C:\\abc\\과제.pptx");
            //@활용하여 표시 가능
            Console.WriteLine(@"C:\abc\과제.pptx");

            //+연산 활용
            //문자열 이어붙이기(숫자도 가능)
            Console.WriteLine("hello"+"world");
            Console.WriteLine("my"+"age"+30);

            //숫자를 문자열로 변환하기
            Console.WriteLine(10+100);//110
            Console.WriteLine("" + 10 + 100);//10100
            Console.WriteLine(10.ToString() + 100);//10100
            Console.WriteLine(10+100+""+200);//110200
            //""을 더함으로 전체를 문자열로 변신시킬수 있다
            //""이전 + 산술덧셈, ""이후 + 문자열로 더해짐
            Console.WriteLine(10+100+""+200+300);//110200300
            Console.WriteLine(10+100+""+(200+300));//110500
            Console.WriteLine(int.Parse(10+100+"")+200+300);//610

            //문자열의 일부분을 가져오기
            string hello1 = "안녕하세요";
            string hello2 = "Hello Everyone";
            Console.WriteLine(hello1[0]);
            Console.WriteLine(hello2[0]);//가방 첫번째 글자 추출
            string one = "472";
            string two = "385";

            //Console.WriteLine(int.Parse(one)* int.Parse(two[2]));
            Console.WriteLine(int.Parse(one)*two[2]);//엉뚱한 값이 출력됨
            //아스키코드 때문에 엉뚱한 값이 출력된다.

            //char 값은 바로 숫자로 변환가능
            Console.WriteLine(int.Parse(one)*two[2]-'0');
            Console.WriteLine(int.Parse(one)*char.GetNumericValue(two[2]));
            //two[2]는 글자이므로 문자열로 변경후 다시 숫자로 변경하기
            Console.WriteLine(int.Parse(one)*int.Parse(two[2]+""));
            Console.WriteLine(int.Parse(one)*int.Parse(two[2].ToString()));

            Console.WriteLine('a'+100); //'a' -> 아스키코드 97이므로 197 출력

            Boolean t = false;
            bool tt = true;

            int a = 100;
            Console.WriteLine(++a + a++);//202
            Console.WriteLine(a);//102

            

            Console.ReadLine();
            int.Parse(Console.ReadLine());
            int.TryParse(Console.ReadLine(), out int ex);
            //도구 - 코드조각 - CSharp - 가져오기

            */
            int a = 105;
            if (a == 105)
            {
                Console.WriteLine("a는 ");
                Console.WriteLine("105!!");

            }
            //if (a == 105)
            {
                Console.WriteLine("조건에 관계없이 출력시");
            }

            //JAVA에서
            //if(a == 100) {
                Console.WriteLine("");
            //}

            //ctrl k f - 모두정렬


        }
    }
}
