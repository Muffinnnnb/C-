﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myCsharp_04_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] arr_1 = { 10, 100, -500 }; //3칸짜리 배열 값정해짐
            int[] arr_2 = new int[10]; //10칸짜리 배열 값 0으로 통일

            Console.WriteLine("arr_1의 길이는"+arr_1.Length+"입니다");
            Console.WriteLine("arr_2의 길이는" + arr_2.Length + "입니다");
            int[,] arr_1_dim_1 = { { 10, 20, 30 }, { 40, 50, 60 } }; //C#의 2차원 배열
            int[,] arr_2_dim_2 = new int[2, 3];

            //조건 확인후 실행
            //0~무한대 번 실행
            int count = 0;
            while (count<arr_1.Length)
            {
                Console.WriteLine(arr_1[count]);
                count++;
            }
            //무조건 한번은 실행후 조건확인
            //1~무한대 번 실행
            do
            {
                Console.WriteLine("count값은"+count+"입니다");
            } while (count < arr_1.Length);

            for(int i=0;i<arr_1.Length;i++)
                Console.WriteLine(arr_1[i]);

            //가 부터 힣까지 모두 출력
            for (char i = '가'; i <= '힣'; i++)
                Console.Write(i);
            

        }
    }
}
