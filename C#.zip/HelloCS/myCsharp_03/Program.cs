﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myCsharp_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
            Console.WriteLine("몇점?");
            //0~50점
            //51~80점
            //81~100점
            int score = 49;
            if(score>=0&&score<51)//0<=score<51 (X)
                Console.WriteLine("밥 없음");
            else if(score>=51&&score<81)
                Console.WriteLine("밥");
            else
            {
                if (score >= 81 && score <= 100)
                    Console.WriteLine("졸업");
                else
                    Console.WriteLine("??" + score);
            }
            */

            int month = 7;
            switch (month)
            {
                case 1:
                    Console.WriteLine("1월");
                    break;
                case 2:
                    Console.WriteLine("10월");
                    break;
                default:
                    Console.WriteLine(month+"월 입니다");
                    break;
            }
            switch (month)
            {
                case 12://case 밑에 코드가 없고 braek도 없으면 그 밑에 있는 경우와
                case 1://같은 결과값을 출력한다
                case 2:
                    Console.WriteLine("겨울");
                    break ;//출력값이 있으면 반드시 break;
                case 6:
                case 7:
                case 8:
                    Console.WriteLine("여름");
                    break;
                case 9:
                case 10:
                case 11:
                    Console.WriteLine("가을");
                    break;

                default:
                    break;
            }
            //switch문은 if문으로 바꿀수 있다
            //switch문으로는 실수범위 안됨

            //삼항 연산자
            int test = 101;
            if(test%2 == 0)
                Console.WriteLine("짝수");
            else
                Console.WriteLine("홀수");

            Console.WriteLine(test%2==0 ? "짝수":"홀수");
            
            bool isEven=test%2==0 ? true : false;
            Console.WriteLine(isEven);

            if("안녕하세요".Contains("안녕"))
                Console.WriteLine("인사했다");

            if ("Hello World".Contains("hello"))
                Console.WriteLine("영어인사");
            else
                Console.WriteLine("대소문자 구분");

            Console.WriteLine("종료시 엔터");
            Console.ReadLine();
            //베포시 release
#if DEBUG
#elif !DEBUG
            while(true)
            {

            }
#endif
        }
    }
}
