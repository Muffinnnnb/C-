﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void Rnd(int num)
        {
            Random rnd = new Random();
            int mynum = rnd.Next(10) + 1;
            if (num == mynum)
            {
                MessageBox.Show($"정답!! (랜덤숫자: {mynum})");
            }
            else
            {
                MessageBox.Show($"오답.. (랜덤숫자: {mynum})");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Rnd(1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Rnd(2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Rnd(3);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Rnd(4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Rnd(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Rnd(6);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Rnd(7);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Rnd(8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Rnd(9);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Rnd(10);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
