﻿using System; //
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace MyMamespace
{
    internal class Program
    {


        public static void aaa(string[] args)
        {

            Console.WriteLine("aaaa!!!!!!");



        }

    }
}














namespace ConsoleApp1 
{
    internal class Program 
    {


        static void aaa(string[] args)
        {

            Console.WriteLine("aaa");



        }
        static void Main(string[] args)
        {

            Console.WriteLine("Hello");
            Console.WriteLine("안녕하세요");
            aaa(null);
            MyMamespace.Program.aaa(null);



        }
    }
}
