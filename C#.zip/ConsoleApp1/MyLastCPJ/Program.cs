﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLastCPJ
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string test = "my test";
            string test2 = "my " + "ldj" + " test";
            string test3 = string.Format("my {0} test {1}", "ldj", 123);
            string test4 = $"my age is {34} and my name is {"이동준"}";
            Console.WriteLine(test);
            Console.WriteLine(test2);
            Console.WriteLine(test3);
            Console.WriteLine(test4);

            Product p = new Product();

            p.StoreName = "신비한 상점";
            Console.WriteLine(p.StoreName);

            p.Name = "물약";
            p.amount = 100;
            Console.WriteLine(p.amount);

            Product p2 = new Product("두용칩",1,999,"저승",0,0);

            Mobile m = new Mobile();
            m.Name = "s20";
            m.modelName = "갤럭시";
            m.buy();
            m.buy(10);
            m.Call();


            List<int> numbers = new List<int>();
            numbers.Add(10);
            numbers.Add(-10);
            numbers.Remove(10);

            Console.WriteLine(numbers[0]);

            List<Product> products = new List<Product>();
            products.Add(p);
            products.Add(p2);
            List<Mobile> mobiles = new List<Mobile>();
            mobiles.Add(m);
            mobiles.Clear();// List 내용 다 지움



            //C#에서의 ArrayList는 뭐든지 저장
            ArrayList myList = new ArrayList();
            myList.Add(10);
            myList.Add(m);
            myList.Add(p);
            myList.Add("숫자 문자열 문자 뿐만 아니라 객체도 저장됨");















        }
    }
}
