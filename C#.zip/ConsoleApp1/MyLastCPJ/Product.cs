﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLastCPJ
{
    internal class Product
    {
        public string Name;
        public int Price;

        private int Product_code;

        public int get_Product_code()
        {
            return Product_code;

        }
        public void set_Product_code(int pcode)
        {
            Product_code = pcode;

        }


        public string StoreName { get; set; }      //축약1

        private int amt;

        public int amount { get { return amt; } set { amt = value; } } //축약2

        //제품이 뭔지 모를때, 생성자 안적으면 이게 자동 생성자
        public Product() { }


        //제품을 만듦과 동시에 뭔지 알때
        public Product(string name, int price, int product_code, string storeName, int amt, int amount)
        {
            Name = name;
            Price = price;
            Product_code = product_code;
            StoreName = storeName;
            this.amt = amt;
            this.amount = amount;
        }


        //오버로딩: 함수나 생성자가 이름은 같지만 입력값이나 입력 갯수가 다를때 서로 다른 함수나 생성자로 간주하는것


        //buy 함수(=메소드)
        //안에 있는 변수가 다르니 다른함수로 받을 수 있다
        public void buy(int a)
        {
            Console.WriteLine(a + "개 구매하셨습니다.");
        }
        public void buy()
        {
            Console.WriteLine("구매를 시작하려고 합니다.");
        }



    }
}
