﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("printf 나 System.out.prinyln과 같음");
            Console.WriteLine("printf(\"\\n\");");
            Console.WriteLine(@"\");// 문자열 앞에 앞에 @있으면 \",\\필요 없음(걍 ",\) 이스케이프 문자 기능을 잃고 일반 문자가 됨 
            Console.Write("라인 안띄우는 것");
            Console.Write(" 이다!");

            Console.WriteLine("자동완성이 좋다.");

            const int CNT = 10;
            
            Console.WriteLine(CNT);

            string abc = "a@b@c";
            //string[] aaa=

            Console.WriteLine("안녕"+ "하세요");

            string hello = "안녕하세요";
            string hello2 = "Hello World";
            Console.WriteLine(hello[0]);
            Console.WriteLine(hello2[0]);

            Console.WriteLine(hello[0]+hello[0]);
            //아스키 코드를 더해버림
            Console.WriteLine(1+99+""+100);//100100 문자열을 만나는 순간부터 문자열 더하기됨

            int a = 10;

            Console.WriteLine(++a + a++ + "" + ++a + a++);
            //11+11+""+13+13
            Console.WriteLine(a); //14

            // string output = Console.ReadLine();
            // Console.WriteLine(output);

            // int input = int.Parse(Console.ReadLine());// int.TryParse 혹은 try catch
            //Console.WriteLine(input+100);

            //Console.WriteLine(input.ToString() + 100.ToString());
            //int.Parse는 문자열을 숫자로(공백이나 문자열은 한글로 못바꿈)
            //ToString()

            //cr,intrr,등등 코드조각설정


            int[] test = { 1, 2, 3, 4 };
            foreach (var item in test)
                
                Console.WriteLine(item);










        }
    }
}
