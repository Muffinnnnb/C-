﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp_Start_WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            button2.Click += Button2_Click;

            btn_test.Click += myfunction;    


        }

        private void myfunction(object sender, EventArgs e)
        {
            MessageBox.Show("이벤트는 이런식으로 늘린다");
            MessageBox.Show($"TextBox1의 값은 {textBox1.Text}입니다.");
        }
        private void Button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("버튼2 클릭함");


            Random rnd = new Random();
            int mynum = rnd.Next(10);// 0부터9까지
            textBox1.Text = mynum.ToString();

            int number = int.Parse(textBox1.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Test");
        }

 
    }
}
