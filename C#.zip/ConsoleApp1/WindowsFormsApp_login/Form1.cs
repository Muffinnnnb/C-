﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp_login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose(); //화면끄기
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.youtube.com");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("환영합니다!");
            MessageBox.Show($"ID는 {textBox1.Text}, PW는 {textBox2.Text}입니다.");


        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
