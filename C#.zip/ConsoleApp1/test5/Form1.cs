﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace test5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            int[] mynum = new int[7];
            Label[] labels = new Label[7];
            labels[0] = label1;
            labels[1] = label2;
            labels[2] = label3;
            labels[3] = label4;
            labels[4] = label5;
            labels[5] = label6;
            labels[6] = label7;

            for (int i = 0; i < mynum.Length; i++)
            {
                int num = rnd.Next(45) + 1;
                int d = 0;
                int j = i - 1;

                //if (mynum.Contains(num))
                //{
                //    i--;
                //    continue;
                //}


                bool isduplicate = false;
                for (int k = 0; k < i; k++)
                {
                    if (mynum[k] == num)
                    {
                        i--;
                        isduplicate = true;
                        break;
                    }
                }
                if (isduplicate)
                    continue;

                mynum[i] = num;

                //if (j >= 0 && mynum[i] == mynum[j])
                //{ 
                //    i--;
                //    continue;
                //}

                int index = i;
                while (index >= 1 && j >= 0)
                {
                    if (mynum[index] < mynum[j])
                    {
                        d = mynum[index];
                        mynum[index] = mynum[j];
                        mynum[j] = d;
                    }
                    labels[j].Text = "" + mynum[j];
                    labels[index].Text = "" + mynum[index];
                    index--;
                    j--;
                }
            }

            //MessageBox.Show(""+mynum[0] +" "+ mynum[1] + " " + mynum[2] + " " + mynum[3] + " " + mynum[4] + " " + mynum[5] + " " + mynum[6]);

        }
    }
}
