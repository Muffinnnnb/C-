﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;




namespace Study_Observer
{
    public partial class Form1 : Form,ISubject
    {

        //List<IObserver> observers=new List<IObserver>();
        IList oberserbers = new ArrayList();

        public Form1()
        {
            InitializeComponent();
            SubForm1 sub1 = new SubForm1(this);
            SubForm2 sub2 = new SubForm2(this);
            

            sub1.TopLevel = false;
            sub1.FormBorderStyle = FormBorderStyle.None;
            sub1.Dock = DockStyle.Fill;
            panel1.Controls.Add(sub1);
            sub1.Show();


            sub2.TopLevel = false;
            sub2.FormBorderStyle = FormBorderStyle.None;
            sub2.Dock = DockStyle.Fill;
            panel2.Controls.Add(sub2);
            sub2.Show();

            RemoveTest rt = new RemoveTest(this,sub1,sub2);
            rt.TopLevel = false;
            rt.FormBorderStyle = FormBorderStyle.None;
            rt.Dock = DockStyle.Fill;
            panel3.Controls.Add(rt);
            rt.Show();





        }

        public void notifyObserver()
        {
            foreach (IObserver item in oberserbers)
            {
                item.update(textBox1.Text);
            }
        }

        public void registerObserver(IObserver o)
        {
            oberserbers.Add(o);
            
            //throw new NotImplementedException();
        }

        public void removeObserver(IObserver o)
        {
            oberserbers.Remove(o);
            //throw new NotImplementedException();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                notifyObserver();
        }
    }
}
