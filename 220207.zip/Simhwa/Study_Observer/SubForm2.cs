﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Study_Observer
{
    public partial class SubForm2 : Form, IObserver
    {
        public SubForm2()
        {
            InitializeComponent();
        }

        public SubForm2(ISubject sub)
        {
            InitializeComponent();

            sub.registerObserver(this);
        }

        public void update(string value)
        {
            textBox1.Text = value+" 두번째 폼";
        }

        private void SubForm2_Load(object sender, EventArgs e)
        {

        }
    }
}
