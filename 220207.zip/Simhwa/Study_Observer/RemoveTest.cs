﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Study_Observer
{
    public partial class RemoveTest : Form
    {

        SubForm1 sb1;
        SubForm2 sb2;
        ISubject sub;

        public RemoveTest()
        {
            InitializeComponent();
        }
        public RemoveTest(ISubject sub, SubForm1 sb1, SubForm2 sb2)
        {
            InitializeComponent();

            this.sub = sub;
            this.sb1 = sb1;
            this.sb2 = sb2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            sub.removeObserver(sb1);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sub.registerObserver(sb1);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            sub.removeObserver(sb2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            sub.registerObserver(sb2);
        }
    }
}
