﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simhwa
{
    public class Product : IComparable
    {

        public string Name { get; set; }
        public int Price { get; set; }


        public override string ToString()
        {
            return "제품명 : " + Name + ", 가격 : " + Price;
        }

        public int CompareTo(object obj)
        {
            return this.Price.CompareTo((obj as Product).Price);
        }


        public Product(string Name, int Price)
        {
            this.Name = Name;
            this.Price = Price;

        }

    }
}
