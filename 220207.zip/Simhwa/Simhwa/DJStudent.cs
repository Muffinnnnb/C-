﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simhwa
{
    public class DJStudent : Student, ISleep, IStudy
    {
        public void DoSleep()
        {
            Console.WriteLine("DJ잔다");
        }

        public void DoStudy()
        {
            Console.WriteLine("DJ공부");
        }

        public override void playGame()
        {
            Console.WriteLine("DJ게임");
        }
    }
}
