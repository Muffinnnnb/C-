﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simhwa
{
    internal class KbStudent : Student, IStudy, ISleep
    {
        public void DoSleep()
        {
            Console.WriteLine("잠을 잔다");
        }

        public void DoStudy()
        {
            Console.WriteLine("공부한다");
        }

        public override void playGame()
        {
            Console.WriteLine("게임한다");
        }





    }
}
