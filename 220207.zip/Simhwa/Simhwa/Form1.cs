﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Simhwa
{
    public partial class Form1 : Form
    {

        struct Rectangle
        {
            public int x, y;

        }


        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Twice t = new Twice();
            t[10] = 5;  //10의 2배인 20을 출력
            Console.WriteLine(t[11]);
            int.TryParse(textBox1.Text, out int value);
            MessageBox.Show(value + "의 2배는 " + t[value]);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySquare m=new MySquare();
            int.TryParse(textBox2.Text, out int value);
            MessageBox.Show(value+"의 제곱은"+m[value]);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Rectangle r;
            r.x = int.Parse(textBox3.Text);
            r.y = int.Parse(textBox4.Text);
            MessageBox.Show("사각형의 넓이 " + (r.x*r.y));

            Rectangle r2=r;
            r2.x = r2.x * 2;
            // 구조체는 깊은 복사됨
            Console.WriteLine("사각형의 넓이 " + (r.x * r.y));
            Console.WriteLine("사각형의 넓이 " + (r2.x * r2.y));

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MyRectangle r=new MyRectangle();
            r.x = int.Parse(textBox3.Text);
            r.y = int.Parse(textBox4.Text);
            //MessageBox.Show("사각형의 넓이 " + (r.x * r.y));

            char[] c=new char[3];
            c[0] = 'A';
            c[1] = 'B';
            c[2] = 'C';


            string a = new string(c);
            MessageBox.Show(a);


            MyRectangle r2=r;

            r2.x = r2.x * 2;
            // 클래스는 얕은 복사됨 r2바꾸면 r도 바뀜(참조변수)
            Console.WriteLine("사각형의 넓이 " + (r.x * r.y));
            Console.WriteLine("사각형의 넓이 " + (r2.x * r2.y));

        }

        private void button5_Click(object sender, EventArgs e)
        {
            KbStudent kb =new KbStudent();
            kb.Name = textBox5.Text;

            Console.WriteLine(kb.Name);

            kb.playGame();
            kb.DoSleep();
            kb.DoStudy();


        }

        private void button6_Click(object sender, EventArgs e)
        {
           DJStudent kb = new DJStudent();
            kb.Name = textBox5.Text;

            Console.WriteLine(kb.Name);

            kb.playGame();
            kb.DoSleep();
            kb.DoStudy();
        }

        List<Product> list = new List<Product>();

        private void button7_Click(object sender, EventArgs e)
        {
            list.Add(new Product(textBox6.Text,int.Parse(textBox7.Text)));
        }

        private void button8_Click(object sender, EventArgs e)
        {
            foreach(var item in list)
            {
                Console.WriteLine(item);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                list.Sort();
                button8.PerformClick();
            }
            catch (Exception ex)
            {

                throw new Exception(ex.Message + "\n"+ex.StackTrace) ;
            }
        }

        void IntroduceStudent(IStudy stu)
        {
            if(stu is KbStudent)
            {
                Console.WriteLine("경북학생");
                Console.WriteLine("이름은"+(stu as KbStudent).Name);
            }
            if(stu is DJStudent)
            {
                Console.WriteLine("dj이름은" + (stu as DJStudent).Name+"이군");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            IStudy stu1 = new KbStudent();
            (stu1 as KbStudent).Name = textBox8.Text;


            IStudy stu2 = new DJStudent();

            (stu2 as DJStudent).Name = textBox9.Text;

            List<IStudy> studies = new List<IStudy>();

            studies.Add(stu1);
            studies.Add(stu2);
            foreach(var item in studies)
            {
                item.DoStudy();
            }

            //IntroduceStudent(stu1);
            //IntroduceStudent(stu2);


        }
    }
}
