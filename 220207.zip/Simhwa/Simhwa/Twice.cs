﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Simhwa
{
    //값을 2배로 리턴해줌
    internal class Twice
    {
        public int this[int i]
        {
            get { return i * 2; }
            set { Console.WriteLine(i+"의 2배 구하기!"+"  대입문에는"+value+"넣음"); }
        }
    }
}
