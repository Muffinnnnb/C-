﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json.Linq;


namespace Project
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode) { case Keys.W: MessageBox.Show("w"); break;}
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string source="ko", target="en";
            //요청 url 설정
            if (textBox1.Text == "")
            {
                MessageBox.Show("번역할 문장을 입력하세요!");
                return;
            }
            
            switch (comboBox1.Text)
            {
                case "한글":
                    source = "ko";
                    break;
                case "영어":
                    source = "en";
                    break;
                case "일본어":
                    source = "ja";
                    break;
            }
            switch (comboBox2.Text)
            {
                case "한글":
                    target = "ko";
                    break;
                case "영어":
                    target = "en";
                    break;
                case "일본어":
                    target = "ja";
                    break;
            }
            if(source== target)
            {
                textBox2.Text = textBox1.Text;
                MessageBox.Show("번역할 언어를 다시 선택해 주세요!");
                return;
            }



            string url = "https://openapi.naver.com/v1/papago/n2mt";

            //url을 사용해서 httprequest생성
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);

            //Header에 정보 추가
            request.Headers.Add("X-Naver-Client-Id", "mAJtZQ50ak9cUh_VAuee");
            request.Headers.Add("X-Naver-Client-Secret", "jonD5WI6RG");
            request.Method = "POST";
            string query = textBox1.Text; //번역하고자 하는 문장.

            //source ko, target en 한->영 query문장을 번역.
            byte[] byteDataParams = Encoding.UTF8.GetBytes("source="+source+"&target="+target+"&text=" + query);

            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = byteDataParams.Length;

            //request
            Stream rqstream = request.GetRequestStream();
            rqstream.Write(byteDataParams, 0, byteDataParams.Length);
            rqstream.Close();

            //response
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();
            Stream rpstream = response.GetResponseStream();
            StreamReader reader = new StreamReader(rpstream, Encoding.UTF8);

            string text = reader.ReadToEnd();
            response.Close();
            rpstream.Close();
            reader.Close();

            textBox2.Text = text;

            //Json parsing
            JObject ret = JObject.Parse(text);
            textBox2.Text = ret["message"]["result"]["translatedText"].ToString();

            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_MouseHover(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string swap;
            swap = comboBox1.Text;
            comboBox1.Text = comboBox2.Text;
            comboBox2.Text = swap;

            textBox1.Text = textBox2.Text;
            textBox2.Text = "";

        }
    }
}
