﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_DB_PT
{
    public class Person
    {
        public string name { get; set; }
        public int number { get; set; }
        public double height { get; set; }

        public Person(string name, int number, double height)
        {
            this.name = name;
            this.number = number;
            this.height = height;
        }
    }
}
