﻿using My_DB_PT.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_DB_PT
{
    public partial class Menu : Form
    {



        public int all_price = 0;
        public Form1 f1 = new Form1();
        public int page = 0;
        public PictureBox[] picboxs;
        public Label[] labels;
        public int type_num = 0;
        

        public Burger[] menu_burger=new Burger[2];

        public List<Burger> burger_basket =new List<Burger>();



        public void showMenu()
        {
            button1.Show();
            switch (type_num)
            {
                
                case 0:

                    for (int i = 0; i < 2; i++)
                    {
                        if (i + (page * 2) > f1.burgers.Count-1)
                        {
                            picboxs[i].Image = null;
                            labels[i].Text = "";

                            button1.Hide();

                            continue;
                        }
                        if (i + (page * 2)+1 > f1.burgers.Count - 1)
                        {
                            button1.Hide();
                        }
                        menu_burger[i] = f1.burgers[i + page * 2];//버거 배열로 받기


                        ResourceManager rm = Resources.ResourceManager;
                        Bitmap myImage = (Bitmap)rm.GetObject(menu_burger[i].pic);
                        picboxs[i].Image = myImage;   //f1.burgers[i].pic;
                        
                        labels[i].Text = menu_burger[i].name + " 단품 " + menu_burger[i].price.ToString()+ "원";



                    }
                    label1.Text = (page + 1).ToString() + " page";

                    
                    break;
                case 1:
                    for (int i = 0; i < 2; i++)
                    {
                        if (i + (page * 2) > f1.burgers.Count-1 || f1.burgers[i + (page * 2)].category != 0)
                        {
                            picboxs[i].Image = null;
                            labels[i].Text = "";
                            if (i == 1)
                            {
                                button1.Hide();
                            }
                            continue;
                        }
                        menu_burger[i] = f1.burgers[i + page * 2];//버거 배열로 받기

                        ResourceManager rm = Resources.ResourceManager;
                        Bitmap myImage = (Bitmap)rm.GetObject("s_" + menu_burger[i].pic);
                        picboxs[i].Image = myImage;   //f1.burgers[i].pic;
                        labels[i].Text = menu_burger[i].name + " 세트 " + (menu_burger[i].s_price).ToString() + "원";

                        
                    }
                    label1.Text = (page + 1).ToString() + " page";

                    
                    break;
            }
            if (page < 1)
            {
                button2.Hide();
            }
            else
            {
                button2.Show();
            }
        }



        public Menu()
        {
            InitializeComponent();
        }

        public Menu(Form1 _f1)
        {

            f1 = _f1;
            InitializeComponent();
            picboxs = new PictureBox[2]{ pictureBox1,pictureBox2 };
            labels=new Label[2] { label2, label3 };
            showMenu();





        }



        private void button1_Click(object sender, EventArgs e)
        {



            page++;
            showMenu();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (page <= 1)
            {
                button2.Hide();
            }

            page--;
            showMenu();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (type_num == 1)
            {
                page = 0;
                type_num = 0;
                showMenu();
                return;
            }
            page = 0;
            type_num = 1;
            showMenu();

        }

        public Burger s_burger;
        public void pictureBox1_Click(object sender, EventArgs e)
        {


            switch (type_num)
            {

                case 0:

                    s_burger = menu_burger[0].DeepCopy();
                    s_burger.name = s_burger.name + "  " + s_burger.price + "원";
                    burger_basket.Add(s_burger);
                    all_price += s_burger.price;
                    break;
                case 1:

                    s_burger = menu_burger[0].DeepCopy();
                    Side_set Side_set=new Side_set(this);

                    Side_set.ShowDialog();
                    
                    s_burger.name = s_burger.name + "  " + s_burger.price + "원";
                    s_burger.category = 9;
                    burger_basket.Add(s_burger);
                    all_price += s_burger.price;
                    break;
            }



            label4.Text = "총 금액\n"+all_price+"원";

            

            dataGridView1.DataSource = null;
            dataGridView1.DataSource = burger_basket;

            


            // burger_basket[1] = null;
            // dataGridView1.DataSource = null;

            //  burger_basket.Remove(s_burger);
            //  dataGridView1.DataSource = burger_basket;




        }



        private void pictureBox2_Click(object sender, EventArgs e)
        {
            



            switch (type_num)
            {

                case 0:
                    s_burger = menu_burger[1].DeepCopy();
                    s_burger.name = s_burger.name + "  " + s_burger.price + "원";
                    burger_basket.Add(s_burger);
                    all_price += menu_burger[1].price;
                    break;
                case 1:

                    s_burger = menu_burger[1].DeepCopy();
                    Side_set Side_set = new Side_set(this);
                    Side_set.ShowDialog();



                    s_burger.name = s_burger.name + "  " + s_burger.price+"원";
                    s_burger.category = 9;
                    burger_basket.Add(s_burger);
                    all_price += s_burger.price;

                    break;
            }

            label4.Text = "총 금액\n" + all_price + "원";
            //price = new Burger("" + all_price);
            //burger_basket.Add(price);
            //burger_basket.RemoveAt((burger_basket.Count - 1));


            dataGridView1.DataSource = null;
            dataGridView1.DataSource = burger_basket;
            
            






        }

        private void button4_Click(object sender, EventArgs e)
        {
            burger_basket.RemoveAll(burger => true);
            all_price = 0;
            dataGridView1.DataSource = null;
            label4.Text = "총 금액";


        }

        private void button5_Click(object sender, EventArgs e)
        {

            f1.my_burgers = burger_basket;


            Close();
        }
    }
}
