﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_DB_PT
{
    public class Burger
    {
        public string name { get; set; }
        public int price { get; set; }
        public int s_price { get; set; }
        public int category { get; set; }
        public int event_ { get; set; }
        public int b_num { get; set; }

        public string pic { get; set; }

        public Burger(string name, int price, int s_price, int category, int event_, int b_num,string pic)
        {
            this.name = name;
            this.price = price;
            this.s_price = s_price;
            this.category = category;
            this.event_ = event_;
            this.b_num = b_num;
            this.pic = pic;
        }

        public Burger(string name)
        {
            this.name = name;
            this.price = 0;
            this.s_price = 0;
            this.category = 0;
            this.event_ = 0;
            this.b_num = 0;
            this.pic = "";
        }
        public Burger()
        {
            this.name = "";
            this.price = 0;
            this.s_price = 0;
            this.category = 0;
            this.event_ = 0;
            this.b_num = 0;
            this.pic = "";
        }
        public Burger DeepCopy()
        {
            Burger newCopy = new Burger();
            newCopy.name = this.name;
            newCopy.price = this.price;
            newCopy.s_price = this.s_price;
            newCopy.category = this.category;
            newCopy.event_ = this.event_;
            newCopy.b_num = this.b_num;
            newCopy.pic = this.pic;
            return newCopy;
        }
    }
}
