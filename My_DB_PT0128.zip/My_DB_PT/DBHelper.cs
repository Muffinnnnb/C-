﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_DB_PT
{
    public class DBHelper
    {
        MySqlConnection Myconn;
        List<Burger> bgs;
        DataSet ds = new DataSet();
        Burger burger;
        public void ConnectDB()
        {
            string pwd = "1234";
            string strConn = "Server=localhost;Database=new_schema_sss;Uid=root;Pwd=" + pwd + ";Charset=utf8";
            //string pwd = "qlqjs12341234";
            //string strConn = "Server=cyzhsss.iptime.org;Database=my_db;Uid=root;Pwd=" + pwd + ";Charset=utf8";
            Myconn = new MySqlConnection(strConn);
            Myconn.Open();
        }


        public List<Burger> selectQuery()
        {
            try
            {

                ConnectDB();


                

                bgs = new List<Burger>();

                

                string sql = "select * from burger";
                MySqlDataAdapter da = new MySqlDataAdapter();
                MySqlCommand cmd = Myconn.CreateCommand();
                cmd.CommandText = sql;
                da.SelectCommand = cmd;

                


                da.Fill(ds);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    
                    string name = ds.Tables[0].Rows[i]["name"].ToString();
                    int.TryParse(ds.Tables[0].Rows[i]["price"].ToString(), out int price);

                    int.TryParse(ds.Tables[0].Rows[i]["s_price"].ToString(), out int s_price);

                    int.TryParse(ds.Tables[0].Rows[i]["category"].ToString(), out int category);

                    int.TryParse(ds.Tables[0].Rows[i]["event_"].ToString(), out int event_);


                    int.TryParse(ds.Tables[0].Rows[i]["b_num"].ToString(), out int b_num);

                    string pic = ds.Tables[0].Rows[i]["pic"].ToString();
                    //System.Windows.Forms.MessageBox.Show(name);

                    burger = new Burger(name, price, s_price, category, event_, b_num,pic);
                    bgs.Add(burger);

                }
                ds.Clear();     // 데이터셋 클리어

                

                Myconn.Close();
            }
            catch (Exception e)
            {
                Myconn.Close();
                System.Windows.Forms.MessageBox.Show("selectQuery() err");
            }
            return bgs;
        }




        public List<Burger> selectCategory(int num)
        {
            try
            {

                ConnectDB();




                bgs = new List<Burger>();



                string sql = "select * from  burger where category="+num;
                MySqlDataAdapter da = new MySqlDataAdapter();
                MySqlCommand cmd = Myconn.CreateCommand();
                cmd.CommandText = sql;
                da.SelectCommand = cmd;




                da.Fill(ds);

                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {

                    string name = ds.Tables[0].Rows[i]["name"].ToString();
                    int.TryParse(ds.Tables[0].Rows[i]["price"].ToString(), out int price);

                    int.TryParse(ds.Tables[0].Rows[i]["s_price"].ToString(), out int s_price);

                    int.TryParse(ds.Tables[0].Rows[i]["category"].ToString(), out int category);

                    int.TryParse(ds.Tables[0].Rows[i]["event_"].ToString(), out int event_);


                    int.TryParse(ds.Tables[0].Rows[i]["b_num"].ToString(), out int b_num);

                    string pic = ds.Tables[0].Rows[i]["pic"].ToString();
                    //System.Windows.Forms.MessageBox.Show(name);

                    burger = new Burger(name, price, s_price, category, event_, b_num, pic);
                    bgs.Add(burger);

                }
                ds.Clear();     // 데이터셋 클리어



                Myconn.Close();
            }
            catch (Exception e)
            {
                Myconn.Close();
                System.Windows.Forms.MessageBox.Show("selectQuery() err");
            }
            return bgs;
        }






    }
}
