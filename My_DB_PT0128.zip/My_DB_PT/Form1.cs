﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_DB_PT
{
    public partial class Form1 : Form
    {



        public DBHelper db =new DBHelper();
        public List<Burger> burgers;
        public List<Burger> my_burgers;


        public Form1()
        {
            InitializeComponent();

            burgers = db.selectQuery();


        }

        public void button1_Click(object sender, EventArgs e)
        {
            //burgers = db.selectQuery();

            
            dataGridView1.DataSource = my_burgers;
            //MessageBox.Show(persons[0].name);



        }

        private void button2_Click(object sender, EventArgs e)
        {

            Menu menu = new Menu(this);
            menu.Show();
        }
    }
}
