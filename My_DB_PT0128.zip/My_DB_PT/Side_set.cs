﻿using My_DB_PT.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace My_DB_PT
{
    public partial class Side_set : Form
    {
        public DBHelper db = new DBHelper();
        public int page = 0;
        public Menu menu_form;
        public List<Burger> burgerList;
        public int type_num = 1;
        public Burger[] menu_burger = new Burger[2];
        public PictureBox[] picboxs;
        public Label[] labels;
        public Burger[] side = new Burger[2];
        public int price = 0;


        public Side_set()
        {
            InitializeComponent();
        }


        public Side_set(Menu _m)
        {
            menu_form= _m;
            side[0] = db.selectCategory(1)[0];
            side[1] = db.selectCategory(2)[0];
            InitializeComponent();
            burgerList=db.selectCategory(type_num);
            price += side[0].s_price + side[1].s_price + menu_form.s_burger.s_price;
            picboxs = new PictureBox[2] { pictureBox1, pictureBox2 };
            labels = new Label[2] { label2, label3 };

            

            showMenu();

        }

        public void showMenu()
        {
            button1.Show();
            label4.Text = "세트 가격: " + price;


            for (int i = 0; i < 2; i++)
                    {

                    if (type_num==1)
                    {
                    label5.Text = "사이드 메뉴";
                }
                else
                {
                    label5.Text = "음료 메뉴";
                }
                        if (i + (page * 2) > burgerList.Count - 1)
                        {
                            picboxs[i].Image = null;
                            labels[i].Text = "";

                            button1.Hide();

                            continue;
                        }
                        if (i + (page * 2) + 1 > burgerList.Count - 1)
                        {
                            button1.Hide();
                        }
                        menu_burger[i] = burgerList[i + page * 2];//버거 배열로 받기


                        ResourceManager rm = Resources.ResourceManager;
                        Bitmap myImage = (Bitmap)rm.GetObject(menu_burger[i].pic);
                        picboxs[i].Image = myImage;   //f1.burgers[i].pic;

                        labels[i].Text = menu_burger[i].name + " 변경 +" + menu_burger[i].s_price.ToString() + "원";



                    }
                    label1.Text = (page + 1).ToString() + " page";


               
            if (page < 1)
            {
                button2.Hide();
            }
            else
            {
                button2.Show();
            }
        }







        private void button2_Click(object sender, EventArgs e)
        {
            page--;
            showMenu();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            page++;
            showMenu();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (type_num==1)
            {
                button3.Text = "사이드 변경";
                type_num = 2;
            }
            else
            {
                button3.Text = "음료 변경";
                type_num = 1;
            }
            page = 0;
            burgerList = db.selectCategory(type_num);
            showMenu();

        }


        private void pictureBox1_Click(object sender, EventArgs e)
        {
            switch (type_num)
            {

                case 1:

                    side[0] = menu_burger[0].DeepCopy();
                    //menu_form.burger_basket.Add(side[0]);
                    
                    label6.Text = "사이드: " + side[0].name+"\n음료: "+side[1].name;
                    break;
                case 2:
                    side[1] = menu_burger[0].DeepCopy();
                    label6.Text = "사이드: " + side[0].name + "\n음료: " + side[1].name;
                    //menu_form.burger_basket.Add(side[1]);
                    
                    break;
            }
            price = side[0].s_price + side[1].s_price + menu_form.s_burger.s_price;
            label4.Text = "세트 가격: " + price;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            switch (type_num)
            {

                case 1:

                    side[0] = menu_burger[1].DeepCopy();
                    //menu_form.burger_basket.Add(side[0]);
                    
                    label6.Text = "사이드: " + side[0].name + "\n음료: " + side[1].name;
                    break;
                case 2:
                    side[1] = menu_burger[1].DeepCopy();
                    label6.Text = "사이드: " + side[0].name + "\n음료: " + side[1].name;
                    //menu_form.burger_basket.Add(side[1]);
                    
                    break;
            }
            price = side[0].s_price + side[1].s_price + menu_form.s_burger.s_price;
            label4.Text = "세트 가격: " + price;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            menu_form.s_burger.price= price;
            menu_form.s_burger.name = menu_form.s_burger.name + " 세트 (" + side[0].name + ", " + side[1].name+")";




            Close();
        }
    }
}
